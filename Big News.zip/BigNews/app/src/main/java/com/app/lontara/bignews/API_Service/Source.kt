package com.app.lontara.bignews.API_Service

data class Source(
    val id: String,
    val name: String
)