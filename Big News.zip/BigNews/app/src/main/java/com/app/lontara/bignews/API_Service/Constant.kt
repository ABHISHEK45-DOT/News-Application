package com.app.lontara.bignews.API_Service

const val BASE_URL = "https://newsapi.org/v2/"